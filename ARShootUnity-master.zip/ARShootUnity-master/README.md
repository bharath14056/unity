Simple AR shooting game built in unity and C#/mono for Android and iOS

Based on original at:
https://github.com/RudraJikadra/ARShoot-Game-Markerless-Augmented-Reality-Unity3D-iOS-Android
